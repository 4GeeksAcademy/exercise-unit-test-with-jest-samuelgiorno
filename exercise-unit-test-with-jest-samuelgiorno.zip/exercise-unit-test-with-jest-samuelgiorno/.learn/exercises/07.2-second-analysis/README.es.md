# `07.2` Second Analysis

Si comparas la salida de Jest con tu archivo `test.js`, podrás encontrar la descripción de tu prueba y un ✅ o ❌ dependiendo del éxito o fracaso de la prueba.

![Reporte de Jest 2](../../assets/jest-report2.png)
