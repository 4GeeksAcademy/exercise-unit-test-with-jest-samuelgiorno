# `07.2` Second Analysis

If you compare the Jest output with your `test.js` file, you will be able to find your test description and a ✅ or ❌ depending on the test's success or fail.

![Jest Report 2](../../assets/jest-report2.png)
