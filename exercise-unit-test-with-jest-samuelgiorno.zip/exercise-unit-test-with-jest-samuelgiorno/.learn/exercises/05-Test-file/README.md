# `05` Test File

Amazing! Our `sum` function is summing numbers correctly.

We realize that because we are humans, and humans can understand that 7 + 3 = 10.

The `sum` function receives two numbers: `a = 7` and `b = 3`, and returns `10`. We see it on the console because we console.log it.

## 📝 Instructions:

1. The next step is to create a `test.js` file on the root of the project that will include our tests.

## 💡 Hint:

+ Make sure the file `test.js` exists on the root of your project.
