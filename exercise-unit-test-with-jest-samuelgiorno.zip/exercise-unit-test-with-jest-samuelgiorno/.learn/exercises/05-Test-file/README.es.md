---
tutorial: "https://www.youtube.com/watch?v=sr_KWVnIc1Q"
---

# `05` Test File

¡Asombroso! Nuestra función `sum` está sumando números correctamente.

Nos damos cuenta de eso porque somos humanos, y los humanos podemos entender que 7 + 3 = 10.

La función `sum` recibe dos números: `a = 7` y` b = 3`, y nos devuelve `10`. Lo vemos en la consola porque pedimos un registro con console.log.

## 📝 Instrucciones:

1. El siguiente paso es crear un archivo `test.js` en la raíz del proyecto que incluirá nuestras pruebas.

## 💡 Pista:

+ Asegúrate que el archivo `test.js` exista en la raíz de tu proyecto.
